import React from 'react'

export default function Fragments() {
  return (
    <React.Fragment>
      <h1>Fragmen Example in js</h1>
    </React.Fragment>
    
  )
}
